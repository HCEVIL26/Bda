package com.mapreduce.weathermining;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import java.io.IOException;

public class WeatherMapper extends Mapper<LongWritable, Text, Text, Text> {
    @Override
    public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
        // Read the line
        String line = value.toString();
        String[] fields = line.split(",");

        if (fields.length == 4) { // Ensure the line has 4 fields
            String date = fields[0];
            double maxTemp = Double.parseDouble(fields[1]);
            double minTemp = Double.parseDouble(fields[2]);
            double precipitation = Double.parseDouble(fields[3]);

            String weatherCondition;

            // Determine weather condition
            if (maxTemp > 35) {
                weatherCondition = "Hot day";
            } else if (minTemp < 15) {
                weatherCondition = "Cold day";
            } else if (precipitation > 0) {
                weatherCondition = "Rainy day";
            } else if (maxTemp >= 20 && maxTemp <= 30 && precipitation == 0) {
                weatherCondition = "Pleasant day";
            } else {
                weatherCondition = "Normal day";
            }

            // Emit date and weather condition
            context.write(new Text(date), new Text(weatherCondition));
        }
    }
}
