package com.mapreduce.movie;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import java.io.IOException;

public class MovieMapper extends Mapper<Object, Text, Text, Text> {
    @Override
    public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
        String[] fields = value.toString().split(",");
        
        if (fields.length == 3) { // Ensure correct format
            String movieId = fields[1];  // Second column is Movie ID
            String tag = fields[2];      // Third column is Tag
            
            context.write(new Text(movieId), new Text(tag));
        }
    }
}
